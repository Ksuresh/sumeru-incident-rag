---
incident_id: INC-UNKNOWN-0006
date_reported: 
customer_name: Equitas
environment: Production
service_module: website
incident_category: Network issue
severity_level: P1
detected_by: Endusers
owner_resolver: 
incident_tags: 
linked_incidents: 
postmortem_link: 
gpt_insight_label: 
---

# Incident INC-UNKNOWN-0006

## Summary
page is not loading

## Impact Scope
ALL Users

## Observability / Logs


## Root Cause (as recorded)
due to network issues

## Resolution Steps
auto resolved

## Detection & Resolution Timing
- Time to Detect (TTD): 5m
- Time to Resolve (TTR): 20m

## Preventive Actions


## Automation Suggestion

