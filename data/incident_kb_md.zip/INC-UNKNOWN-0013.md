---
incident_id: INC-UNKNOWN-0013
date_reported: 
customer_name: Au bank
environment: UAT
service_module: Endpoint
incident_category: Service
severity_level: P3
detected_by: Client
owner_resolver: 
incident_tags: 
linked_incidents: 
postmortem_link: 
gpt_insight_label: 
---

# Incident INC-UNKNOWN-0013

## Summary
Endpoint is restated aftger throughing the error

## Impact Scope
some users only

## Observability / Logs


## Root Cause (as recorded)
Configuration issue in rabbitmq and  configuration file

## Resolution Steps
in rabbitmq added virtual host and changed the config details in  all endpoint

## Detection & Resolution Timing
- Time to Detect (TTD): 3hr
- Time to Resolve (TTR): 24hr

## Preventive Actions


## Automation Suggestion

